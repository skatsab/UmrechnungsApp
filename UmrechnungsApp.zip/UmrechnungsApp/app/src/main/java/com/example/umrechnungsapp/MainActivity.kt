package com.example.umrechnungsapp

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.umrechnungsapp.ui.theme.UmrechnungsAppTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UmrechnungsAppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    UmrechnerUI()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UmrechnerUI() {
    val context = LocalContext.current
    var selectedOption by remember { mutableStateOf("Fläche in Fußballfelder") }
    var expanded by remember { mutableStateOf(false) }

    val options = listOf(
        "Fläche in Fußballfelder",
        "Alter in Minuten",
        "Geldbetrag in Zeit"
    )

    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    val calendar = Calendar.getInstance()
    val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // Dropdown-Menü
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            TextField(
                value = selectedOption,
                onValueChange = {},
                readOnly = true,
                label = { Text("Wähle eine Umrechnung") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            selectedOption = option
                            expanded = false
                            input = ""
                            result = ""
                        }
                    )
                }
            }
        }

        // Eingabe-Feld: Geburtsdatum oder normale Eingabe
        if (selectedOption == "Alter in Minuten") {
            val today = Calendar.getInstance()

            OutlinedTextField(
                value = input,
                onValueChange = {},
                readOnly = true,
                label = { Text("Geburtsdatum wählen") },
                trailingIcon = {
                    IconButton(onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, day ->
                                calendar.set(year, month, day)
                                input = dateFormat.format(calendar.time)
                            },
                            today.get(Calendar.YEAR),
                            today.get(Calendar.MONTH),
                            today.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = "Datum wählen"
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        DatePickerDialog(
                            context,
                            { _, year, month, day ->
                                calendar.set(year, month, day)
                                input = dateFormat.format(calendar.time)
                            },
                            today.get(Calendar.YEAR),
                            today.get(Calendar.MONTH),
                            today.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }
            )
        } else {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = {
                    Text(
                        when (selectedOption) {
                            "Fläche in Fußballfelder" -> "Fläche in m²"
                            "Geldbetrag in Zeit" -> "Geldbetrag in €"
                            else -> "Eingabe"
                        }
                    )
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Umrechnen-Button
        Button(onClick = onClick@{
            if (input.isBlank()) {
                Toast.makeText(context, "Bitte gib etwas ein", Toast.LENGTH_SHORT).show()
                return@onClick
            }

            try {
                result = when (selectedOption) {
                    "Fläche in Fußballfelder" -> {
                        val m2 = input.toDouble()
                        val fussballfelder = m2 / 7140
                        "Das entspricht ca. %.2f Fußballfeldern.".format(fussballfelder)
                    }

                    "Alter in Minuten" -> {
                        val geburtsdatum = dateFormat.parse(input)
                        geburtsdatum?.let {
                            val jetzt = Date()
                            val diffMillis = jetzt.time - it.time
                            val minuten = diffMillis / 1000 / 60
                            "Du bist ca. %,d Minuten alt.".format(minuten)
                        } ?: "Geburtsdatum ungültig."
                    }

                    "Geldbetrag in Zeit" -> {
                        val betrag = input.toDouble()
                        val tage = betrag / 1_000_000 * 11
                        val jahre = betrag / 1_000_000_000 * 31.7
                        "Das entspricht ca. %.1f Tagen oder %.2f Jahren in Sekunden.".format(tage, jahre)
                    }

                    else -> ""
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Fehler bei der Eingabe", Toast.LENGTH_SHORT).show()
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Umrechnen")
        }

        // Ergebnis-Anzeige
        Text(
            text = result,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewUmrechner() {
    UmrechnungsAppTheme {
        UmrechnerUI()
    }
}
